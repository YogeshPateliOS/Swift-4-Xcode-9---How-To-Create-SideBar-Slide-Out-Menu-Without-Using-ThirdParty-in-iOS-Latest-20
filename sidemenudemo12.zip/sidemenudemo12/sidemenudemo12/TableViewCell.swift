//
//  TableViewCell.swift
//  sidemenudemo12
//
//  Created by Yogesh Patel on 26/12/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {
    @IBOutlet var img: UIImageView!
    
    @IBOutlet var lbl: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
